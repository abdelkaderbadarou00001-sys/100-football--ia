import streamlit as st
import requests
import pandas as pd
import numpy as np
from scipy.stats import poisson
from datetime import date

st.set_page_config(page_title="Choco Football AI", page_icon="⚽", layout="wide")

st.markdown("""
<style>
.stApp { background: #081426; color: #f4f7fb; }
h1, h2, h3 { color: #39A9FF; }
[data-testid="stMetricValue"] { color: #ffffff; }
</style>
""", unsafe_allow_html=True)

st.title("⚽ CHOCO FOOTBALL AI")
st.caption("Assistant statistique de football — estimations, pas garanties de résultat.")
st.warning("Aucun modèle ne peut garantir un pari gagnant. Vérifie les données et ne mise jamais de l'argent que tu ne peux pas perdre.")

@st.cache_data(ttl=900, show_spinner=False)
def fetch_matches(competition_code: str, season: int):
    """Fetch match data from OpenLigaDB for supported competitions only."""
    url = f"https://api.openligadb.de/getmatchdata/{competition_code}/{season}"
    response = requests.get(url, timeout=20)
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, list):
        return []
    rows = []
    for m in payload:
        home = (m.get("team1") or {}).get("teamName", "Équipe domicile")
        away = (m.get("team2") or {}).get("teamName", "Équipe extérieure")
        results = m.get("matchResults") or []
        home_goals, away_goals = None, None
        if results:
            final = max(results, key=lambda x: x.get("resultTypeID", 0))
            home_goals = final.get("pointsTeam1")
            away_goals = final.get("pointsTeam2")
        rows.append({
            "Date": m.get("matchDateTime", ""),
            "Domicile": home,
            "Extérieur": away,
            "Buts domicile": home_goals,
            "Buts extérieur": away_goals,
            "Terminé": m.get("matchIsFinished", False)
        })
    return rows

def poisson_analysis(home_scored, home_conceded, away_scored, away_conceded, home_advantage):
    # A simple baseline model. Inputs are user-supplied averages, not verified team data.
    vals = [home_scored, home_conceded, away_scored, away_conceded]
    if any(v < 0 for v in vals):
        raise ValueError("Les moyennes ne peuvent pas être négatives.")
    home_lambda = max(0.05, np.sqrt(max(home_scored, 0.05) * max(away_conceded, 0.05)) * home_advantage)
    away_lambda = max(0.05, np.sqrt(max(away_scored, 0.05) * max(home_conceded, 0.05)))
    goals = np.arange(11)
    home_p = poisson.pmf(goals, home_lambda)
    away_p = poisson.pmf(goals, away_lambda)
    matrix = np.outer(home_p, away_p)
    matrix /= matrix.sum()
    home_win = float(np.triu(matrix, k=1).sum())  # row index = home goals
    draw = float(np.trace(matrix))
    away_win = float(np.tril(matrix, k=-1).sum())
    total = np.add.outer(goals, goals)
    over15 = float(matrix[total >= 2].sum())
    over25 = float(matrix[total >= 3].sum())
    under35 = float(matrix[total <= 3].sum())
    btts = float(matrix[1:, 1:].sum())
    scores = []
    for h in range(len(goals)):
        for a in range(len(goals)):
            scores.append((f"{h}-{a}", float(matrix[h, a])))
    scores.sort(key=lambda x: x[1], reverse=True)
    return {
        "home_lambda": home_lambda, "away_lambda": away_lambda,
        "home_win": home_win, "draw": draw, "away_win": away_win,
        "over15": over15, "over25": over25, "under35": under35,
        "btts": btts, "scores": scores[:3]
    }

menu = st.sidebar.radio("Menu", ["Accueil", "Matchs disponibles", "Analyser un match", "À propos"])

if menu == "Accueil":
    st.subheader("Bienvenue")
    st.write("Cette première version permet de consulter les rencontres d'une compétition prise en charge par OpenLigaDB et de calculer des estimations statistiques à partir de moyennes saisies manuellement.")
    st.markdown("""
    **Fonctions disponibles**
    - Rencontres et résultats fournis par la source sélectionnée
    - Probabilités estimées : domicile / nul / extérieur
    - Marchés de buts : Plus de 1,5 ; Plus de 2,5 ; Moins de 3,5
    - Les deux équipes marquent (BTTS)
    - Trois scores exacts les plus probables selon le modèle
    """)
    st.info("Cette version ne couvre pas tous les championnats du monde et ne récupère pas automatiquement les statistiques détaillées de chaque équipe.")

elif menu == "Matchs disponibles":
    st.subheader("🌍 Matchs disponibles")
    st.write("OpenLigaDB ne couvre que certaines compétitions. Exemple de code : `bl1` pour la Bundesliga allemande.")
    code = st.text_input("Code de compétition", value="bl1").strip()
    default_season = date.today().year if date.today().month >= 7 else date.today().year - 1
    season = st.number_input("Année de début de saison", min_value=2000, max_value=2100, value=default_season, step=1)
    if st.button("Récupérer les matchs", type="primary"):
        if not code:
            st.error("Entre un code de compétition.")
        else:
            try:
                with st.spinner("Récupération des données..."):
                    rows = fetch_matches(code, int(season))
                if rows:
                    df = pd.DataFrame(rows)
                    st.success(f"{len(df)} rencontre(s) reçue(s) depuis OpenLigaDB.")
                    st.dataframe(df, use_container_width=True, hide_index=True)
                else:
                    st.info("Aucune rencontre retournée. Vérifie le code et la saison.")
            except requests.RequestException as e:
                st.error(f"Source temporairement indisponible ou code non pris en charge. Détail : {e}")
            except Exception as e:
                st.error(f"Erreur inattendue : {e}")

elif menu == "Analyser un match":
    st.subheader("📊 Analyse statistique")
    c1, c2 = st.columns(2)
    with c1:
        home = st.text_input("Équipe à domicile", "Équipe A")
        hs = st.number_input("Moyenne de buts marqués à domicile", 0.0, 10.0, 1.5, 0.1)
        hc = st.number_input("Moyenne de buts encaissés à domicile", 0.0, 10.0, 1.0, 0.1)
    with c2:
        away = st.text_input("Équipe à l'extérieur", "Équipe B")
        as_ = st.number_input("Moyenne de buts marqués à l'extérieur", 0.0, 10.0, 1.1, 0.1)
        ac = st.number_input("Moyenne de buts encaissés à l'extérieur", 0.0, 10.0, 1.4, 0.1)
    advantage = st.slider("Facteur d'avantage domicile (hypothèse du modèle)", 0.80, 1.40, 1.12, 0.01)
    st.caption("Entre les moyennes historiques de buts, idéalement sur 5 à 10 matchs comparables. Elles ne sont pas vérifiées automatiquement dans cette version.")
    if st.button("Lancer l'analyse", type="primary"):
        r = poisson_analysis(hs, hc, as_, ac, advantage)
        st.markdown("### Buts attendus par le modèle")
        a, b = st.columns(2)
        a.metric(home or "Domicile", f"{r['home_lambda']:.2f}")
        b.metric(away or "Extérieur", f"{r['away_lambda']:.2f}")
        st.markdown("### Probabilités 1N2")
        a, b, c = st.columns(3)
        a.metric(f"Victoire {home or 'domicile'}", f"{r['home_win']:.1%}")
        b.metric("Match nul", f"{r['draw']:.1%}")
        c.metric(f"Victoire {away or 'extérieur'}", f"{r['away_win']:.1%}")
        st.markdown("### Marchés de buts")
        market_df = pd.DataFrame([
            {"Marché": "Plus de 1,5 but", "Probabilité estimée": f"{r['over15']:.1%}"},
            {"Marché": "Plus de 2,5 buts", "Probabilité estimée": f"{r['over25']:.1%}"},
            {"Marché": "Moins de 3,5 buts", "Probabilité estimée": f"{r['under35']:.1%}"},
            {"Marché": "Les deux équipes marquent (BTTS)", "Probabilité estimée": f"{r['btts']:.1%}"}
        ])
        st.dataframe(market_df, use_container_width=True, hide_index=True)
        st.markdown("### 🎯 Trois scores les plus probables")
        score_df = pd.DataFrame([{"Score": s, "Probabilité du modèle": f"{p:.2%}"} for s, p in r["scores"]])
        st.dataframe(score_df, use_container_width=True, hide_index=True)
        st.caption("Les scores exacts sont difficiles à prévoir. Les probabilités reposent uniquement sur les moyennes saisies et sur un modèle simple de Poisson.")

else:
    st.subheader("À propos de cette version")
    st.write("Choco Football AI est un prototype d'analyse statistique. Il n'identifie pas les matchs truqués, ne garantit aucun gain et ne doit pas être utilisé comme preuve qu'un match est arrangé.")
    st.write("Les données de matchs dépendent de la disponibilité et de la couverture d'OpenLigaDB. Les statistiques du formulaire sont saisies par l'utilisateur.")
    st.write("Pour progresser : connecter d'autres sources autorisées, calculer automatiquement les moyennes historiques, conserver les prédictions avant les matchs et mesurer la calibration sur des rencontres futures.")
