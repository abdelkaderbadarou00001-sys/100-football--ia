# Choco Football AI

Prototype gratuit d'application web Streamlit pour consulter des matchs fournis par OpenLigaDB et calculer des estimations statistiques de football.

## Fichiers
- `app.py` : application
- `requirements.txt` : dépendances Python

## Déploiement depuis un téléphone
1. Crée un dépôt GitHub public nommé `choco-football-ai`.
2. Ajoute `app.py` et `requirements.txt` à la racine du dépôt.
3. Ouvre Streamlit Community Cloud et connecte-le à GitHub.
4. Choisis le dépôt `choco-football-ai`, le fichier principal `app.py`, puis déploie.
5. Une fois le déploiement terminé, ouvre l'adresse fournie par Streamlit dans Chrome.

## Exécution locale
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Limites
- OpenLigaDB ne couvre pas tous les championnats du monde.
- Les moyennes utilisées par l'analyse sont saisies manuellement dans cette version.
- Les probabilités sont des estimations, pas des garanties.
- Ce prototype ne détecte pas les matchs truqués et ne fournit aucune garantie de gains.
